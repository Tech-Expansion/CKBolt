CKBolt brand kit v1.0

logo/svg, logo/png  - horizontal, stacked, mark, line mark, wordmark (ink + reversed). PNGs have transparent backgrounds.
icons/              - favicon.svg/.ico/16/32, apple-touch-icon (180), app icons 1024, PWA 192/512
social/             - 1200x630 share cards, light and dark
tokens/             - colors, type and radius as JSON and CSS variables

Ink #080503 on Paper #FAFAF9. Type: Instrument Sans + JetBrains Mono (Google Fonts, OFL).
Wordmark is outlined Instrument Sans; no font install needed.
Guidelines: https://ckbolt.texlabs.org/brand
